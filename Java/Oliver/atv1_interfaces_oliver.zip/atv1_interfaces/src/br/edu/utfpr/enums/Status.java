package br.edu.utfpr.enums;

public enum Status {
  DISPONIVEL, VENDIDO
}
