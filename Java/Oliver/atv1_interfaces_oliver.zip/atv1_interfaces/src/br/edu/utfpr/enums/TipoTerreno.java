package br.edu.utfpr.enums;

public enum TipoTerreno {
  COM_MURO, SEM_MURO
}
