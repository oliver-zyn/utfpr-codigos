package br.edu.utfpr.interfaces;

public interface Comissao {
  public double TAXA = 0.10;

  public double calcularComissao();
}
